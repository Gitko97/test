package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.ExceptionHandler.NoUserDataException;

@Service
public class LoginServiceImpl implements LoginService {
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private UserListService userService;
	
	@Override
	public void SignUp() {
		
	}

	@Override
	public int login(String inputID,String inputPassword) throws NoUserDataException{
		if(adminService.checkAdminID(inputID) && adminService.checkAdminPassword(inputPassword)) {
			return 0;
		}else if(userService.userLogin(inputID, inputPassword))
			return 1;
		else return -1;
	}
}
