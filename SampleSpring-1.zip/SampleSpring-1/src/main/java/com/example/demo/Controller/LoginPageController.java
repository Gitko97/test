package com.example.demo.Controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.example.demo.Model.User;
import com.example.demo.Service.LoginService;

@Controller
@RequestMapping("/login")
@SessionAttributes("user")
public class LoginPageController {
	
	private final LoginService loginService;
	
	@Autowired
	public LoginPageController(LoginService loginService) {
		this.loginService = loginService;
	}
	
	@GetMapping
	public String setUpForm(Model model) {
		User user = new User(null, null, null, 0);
		model.addAttribute("user",user);
		return "login";
	}
	

	
	@PostMapping(params= {"login"})
	public String login(@ModelAttribute("user") User user,BindingResult result, SessionStatus status) {
		System.out.println("dd");
		return "index";
	}
	
	@PostMapping
	public String defaultMethod() {
		return "index";
	}
	
}
