package com.example.demo.Model;

public class Admin {
	private String adminName;
	
	final private String adminID = "Admin";
	
	final private String adminPassword = "1234";
	
	public Admin(String adminName) {
		this.adminName = adminName;
	}
	
	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	
	public boolean checkID(String inputID) {
		if(this.adminID.equals(inputID)) return true;
		else return false;
	}
	
	public boolean checkPassword(String inputPassword) {
		if(this.adminPassword.equals(inputPassword)) return true;
		else return false;
	}
}
