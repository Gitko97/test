package com.example.demo.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.example.demo.Model.User;

@Component
public class UserListServiceImpl implements UserListService {

	private final List<User> userList = new ArrayList<>();
	@Override
	public User checkUserID(String inputID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean userLogin(String inputID, String inputPassword) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
