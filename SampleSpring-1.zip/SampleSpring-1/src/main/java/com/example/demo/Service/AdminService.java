package com.example.demo.Service;

public interface AdminService {
	public boolean checkAdminID(String inputID);
	public boolean checkAdminPassword(String inputPassword);
	public void changeAdminName(String adminName);
}
