package com.example.demo.Model;

public class User {
	
	private String userName;
	
	private String userID;
	
	private String userPassword;
	
	private int age;

	public User(String userName, String userID, String userPassword, int age) {
		this.userName = userName;
		this.userID = userID;
		this.userPassword = userPassword;
		this.age = age;
	}
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
	public boolean equalID(String userID) {
		if(this.userID.equals(userID)) return true;
		else return false;
	}
	
	public boolean equalPassword(String userPassword) {
		if(this.userPassword.equals(userPassword)) return true;
		else return false;
	}
}
