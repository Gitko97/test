package com.example.demo.ExceptionHandler;

public class IDOverlapException extends RuntimeException{

}
