package com.example.demo.Service;

import org.springframework.stereotype.Service;

import com.example.demo.Model.Admin;

@Service
public class AdminServiceImpl implements AdminService {

	private final Admin admin = new Admin("Administrator");
	@Override
	public boolean checkAdminID(String inputID) {
		return admin.checkID(inputID);
	}

	@Override
	public boolean checkAdminPassword(String inputPassword) {
		return admin.checkPassword(inputPassword);
	}
	
	
	public void changeAdminName(String adminName) {
		admin.setAdminName(adminName);
	}
}
