package com.example.demo.Service;

import com.example.demo.ExceptionHandler.NoUserDataException;

public interface LoginService {
	public void SignUp();
	public int login(String inputID,String inputPassword) throws NoUserDataException;
}
