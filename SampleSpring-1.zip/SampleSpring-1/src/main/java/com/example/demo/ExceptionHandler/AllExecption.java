package com.example.demo.ExceptionHandler;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class AllExecption {
	
	@ExceptionHandler(NoUserDataException.class)
	public String handler(NoUserDataException ex) {
		return "noUserData";
	}
	
	@ExceptionHandler
	public String defaultHandler(Exception e) {
		return "error";
	}
	
	
}
