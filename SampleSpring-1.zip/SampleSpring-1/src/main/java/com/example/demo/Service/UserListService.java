package com.example.demo.Service;

import com.example.demo.Model.User;

public interface UserListService {
	public User checkUserID(String inputID);
	public void addUser(User user);
	public boolean userLogin(String inputID,String inputPassword);
}
