package com.example.demo.ExceptionHandler;

public class NoUserDataException extends RuntimeException{

}
