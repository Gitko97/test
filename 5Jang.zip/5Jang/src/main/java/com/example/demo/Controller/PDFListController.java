package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.example.demo.Model.MyClient;
import com.example.demo.Service.ClientListService;

@Controller
@RequestMapping("/pdfList")
public class PDFListController {

	private final ClientListService listService;

	@Autowired
	public PDFListController(ClientListService listService) {
		this.listService = listService;
	}

	
	@RequestMapping(method = RequestMethod.GET)
	public String generateSummary(Model model) {

		List<MyClient> clients = listService.getClientList();
		model.addAttribute("clients", clients);
		System.out.println("오예");
		return "pdfListView";
	}
	
}
