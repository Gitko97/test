package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.Service.ClientListService;

@Controller
@RequestMapping("/loginSuccess")
public class LoginSuccess {
	
	@Autowired
	private ClientListService clientListSerivce;
	
	@RequestMapping(method=RequestMethod.GET)
	public String setUp(@RequestParam("clientType") String clientType,Model model) {
		System.out.println(clientType);
		model.addAttribute("ID", new String());
		model.addAttribute("clientType",clientType);
		System.out.println("loginSuccess");
		return "loginSuccessView";
	}
	
	@PostMapping(params= {"delete"})
	public String DeleteClient(@ModelAttribute("clientType")String clientType,@ModelAttribute("ID")String deleteID,Model model) {
		System.out.println(deleteID);
		clientListSerivce.deleteClient(deleteID);
		return "redirect:loginSuccess?clientType="+clientType;
	}
}
