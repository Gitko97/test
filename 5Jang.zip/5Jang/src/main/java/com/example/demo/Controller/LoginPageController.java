package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.example.demo.Model.MyClient;
import com.example.demo.Service.LoginService;

@Controller
@RequestMapping("/login")
@SessionAttributes("client")
public class LoginPageController {
	
	private final LoginService loginService;
	
	@Autowired
	public LoginPageController(LoginService loginService) {
		this.loginService = loginService;
	}
	
	@GetMapping
	public String setUpForm(Model model) {
		MyClient client = new MyClient(null,null);
		model.addAttribute("client",client);
		return "login";
	}
	

	
	@PostMapping(params= {"login"})
	public String login(@ModelAttribute("client") MyClient client,BindingResult result, SessionStatus status) {
		status.setComplete();
		switch(loginService.login(client)) {
		case 0 : return "redirect:/loginSuccess?clientType=Admin";  
		case 1 : return "redirect:/loginSuccess?clientType=User";
		default : 
		}
			return "NoUserDataException"; 
	}
	
	@PostMapping(params= {"signUp"})
	public String login() {
		return "redirect:signUp";
	}
	
	
	@PostMapping
	public String defaultMethod() {
		return "index";
	}
	
}
