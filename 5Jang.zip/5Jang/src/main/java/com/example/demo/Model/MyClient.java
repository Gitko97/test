package com.example.demo.Model;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn
@Table(name="myClient")
public class MyClient {
	@Id
	protected String ID;
	protected String Password;
	

	public MyClient() {}
	
	public MyClient(String inputID, String inputPassword) {
		this.setID(inputID);
		this.setPassword(inputPassword);
	}
	
	@JsonIgnore
	public String getID() {
		return ID;
	}
	
	public void setID(String iD) {
		ID = iD;
	}

	@JsonIgnore
	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}
	public boolean equalID(String userID) {
		if(this.ID.equals(userID)) return true;
		else return false;
	}
	public boolean equalPassword(String userPassword) {
		if(this.Password.equals(userPassword)) return true;
		else return false;
	}
}
