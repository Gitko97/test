package com.example.demo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.Model.MyClient;

public interface JpaRepo extends JpaRepository<MyClient, String> {

}
