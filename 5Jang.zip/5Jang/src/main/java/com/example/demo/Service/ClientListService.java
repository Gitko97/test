package com.example.demo.Service;

import java.util.List;

import com.example.demo.Model.MyClient;

public interface ClientListService {
	public boolean checkOverLap(String inputID);
	public void addClient(MyClient client);
	public boolean clientLogin(String inputID,String inputPassword);
	public void print();
	public List<MyClient> getClientList();
	public MyClient findClient(String inputID);
	public List<MyClient> findClientName(String inputName);
	public void setList(List<MyClient> clients);
	public void deleteClient(String deleteID);
}
