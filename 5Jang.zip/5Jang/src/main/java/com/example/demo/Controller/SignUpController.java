package com.example.demo.Controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import com.example.demo.Model.MyClient;
import com.example.demo.Model.User;
import com.example.demo.Service.LoginService;

@Controller
@RequestMapping("/signUp")
@SessionAttributes("client")
public class SignUpController {

	private final Map<Integer, String> pageForms = new HashMap<>(2);
	private final LoginService loginService;
	private boolean overLap;
	 
	@Autowired
	public SignUpController(LoginService loginService) {
		this.loginService = loginService;
		this.overLap = false;
		pageForms.put(0, "IDPWsignUp");
		pageForms.put(1, "userDatasignUp");
	}
	
	@GetMapping
	public String setUpForm(Model model) {
		MyClient client = new User(null,null,null,0);
		model.addAttribute("client",client);
		return "IDPWsignUp";
	}
	
    @PostMapping(params = {"_cancel"})
    public String cancelForm(SessionStatus status) {
    	status.setComplete();
    	this.overLap = false;
        return "redirect:/";
    }
    
    @PostMapping(params = {"_finish"})
    public String completeForm(
           @Validated @ModelAttribute("client") MyClient client,
            BindingResult result, SessionStatus status,
            @RequestParam("_page") int currentPage) {
    	if(result.hasErrors()) return "clientDatasignUp";
    	this.overLap = false;
    	loginService.addClient(client);
    	status.setComplete();
    	return "redirect:login";
    }
    
    @PostMapping(params = {"_overLap"})
    public String checkOverLap(
             @ModelAttribute("client") MyClient client,SessionStatus status,Model model,Errors errors) {
    		if(loginService.overlapCheck(client)) {
    			this.overLap = false;
    			errors.rejectValue("ID", "signUp.overLapFalse");
    		}else {
    			this.overLap = true;
    			errors.rejectValue("ID", "signUp.overLapTrue");
    		}
    		return "IDPWsignUp";
     }
    
    @PostMapping(params = {"_next"})
    public String nextForm(
            HttpServletRequest request,
            @ModelAttribute("client") MyClient client,
            BindingResult result, @RequestParam("_page") int currentPage) {
    	if(!overLap) return "IDPWsignUp";
        int targetPage = currentPage + 1;
        if (targetPage < currentPage) {
            return pageForms.get(targetPage);
        }
        if (!result.hasErrors()) {
            return pageForms.get(targetPage);
        } else {
            return pageForms.get(currentPage);
        }
    }
    
    @PostMapping(params = {"_previous"})
    public String prevForm(
            HttpServletRequest request,
            @ModelAttribute("client") MyClient client,
            BindingResult result, @RequestParam("_page") int currentPage) {
    	
        int targetPage = currentPage - 1;
        System.out.println(targetPage);
        if (targetPage < currentPage) {
            return pageForms.get(targetPage);
        }

        if (!result.hasErrors()) {
            return pageForms.get(targetPage);
        } else {
            return pageForms.get(currentPage);
        }
    }
    
	

}
