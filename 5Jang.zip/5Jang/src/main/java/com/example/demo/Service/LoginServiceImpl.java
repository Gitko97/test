package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.Admin;
import com.example.demo.Model.MyClient;

@Service
public class LoginServiceImpl implements LoginService {
	@Autowired
	private Admin adminService;
	
	@Autowired
	private ClientListService clientService;
	
	@Override
	public void SignUp(MyClient client) {
		
	}

	@Override
	public int login(MyClient client){
		String inputID = client.getID();
		String inputPW = client.getPassword();
		System.out.println(inputID + "/" + inputPW);
		if(adminService.checkID(inputID) && adminService.checkPassword(inputPW)) {
			return 0;
		}else if(clientService.clientLogin(inputID, inputPW))
			return 1;
		else return -1;
	}

	@Override
	public boolean overlapCheck(MyClient client) {
		String inputID = client.getID();
		System.out.println(inputID);
		if(adminService.checkID(inputID) || clientService.checkOverLap(inputID)) {
			return true;
		}else return false;
	}

	@Override
	public String getClientType(MyClient client) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addClient(MyClient client) {
		clientService.addClient(client);
		clientService.print();
	}


}
