package com.example.demo.Model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@XmlRootElement
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@Entity
@Table(name="userData")
@DiscriminatorValue("users")
public class User extends MyClient {
	
	private String userName;

	private int age;

	public User(String userName, String ID, String Password, int age) {
		this.userName = userName;
		this.ID = ID;
		this.Password = Password;
		this.age = age;
	}
	
	public User() {
		
	}
	

	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}


	@Override
	public String toString() {
		return "User [userName=" + userName + ", age=" + age + ", ID=" + ID + ", Password=" + Password + "]";
	}


	
}
