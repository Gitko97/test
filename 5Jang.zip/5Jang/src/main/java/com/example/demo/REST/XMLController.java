package com.example.demo.REST;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.MyClient;
import com.example.demo.Service.ClientListService;
import com.example.demo.Service.ClientListServiceImpl;

@RestController
@RequestMapping("/clientListInfo")
public class XMLController {
	private final ClientListService clientListService;

	@Autowired
	public XMLController(ClientListService clientListService) {
		this.clientListService = clientListService;
	}

	@RequestMapping(produces = MediaType.APPLICATION_XML_VALUE)
	@ResponseBody
	public ClientListService getRestClientListXML(Model model,HttpServletResponse resp) {
		System.out.println("REST");
		model.addAttribute("clientList", clientListService.getClientList());
		return clientListService;
	}

	
	@RequestMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ClientListService getRestClientListJson(Model model) {
		model.addAttribute("clientList", clientListService.getClientList());
		return clientListService;
	}
	 

	@RequestMapping(value = "/{ID}", produces = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<MyClient> getRestClientList(@PathVariable("ID") String inputID) {
		MyClient client = clientListService.findClient(inputID);

		if (client == null)
			return new ResponseEntity<MyClient>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<MyClient>(client, HttpStatus.OK);
	}

	// @RequestMapping(value = "/*/{ID}",produces = MediaType.APPLICATION_XML_VALUE)
	// @ResponseBody
	/*
	 * public ResponseEntity<Client> getRestClientList2(@PathVariable("ID") String
	 * inputID){ Client client = clientListService.findClient(inputID);
	 * 
	 * if(client == null) return new ResponseEntity<Client>(HttpStatus.NOT_FOUND); else
	 * return new ResponseEntity<Client>(client, HttpStatus.OK); }
	 */

	@RequestMapping(value = "/name/{clientName}", produces = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<ClientListService> getRestClientList0(@PathVariable("clientName") String inputName) {
		List<MyClient> clients = clientListService.findClientName(inputName);
		ClientListService clientService = new ClientListServiceImpl(null);
		clientService.setList(clients);
		if (clients == null)
			return new ResponseEntity<ClientListService>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<ClientListService>(clientService, HttpStatus.OK);
	}

}
