package com.example.demo.Config;

import javax.annotation.Resource;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
@Configuration
public class HandlerInterceptorConfig implements WebMvcConfigurer {
    ////////핸들러 인터셉터 선언
    @Resource(name="timeInterceptor")
    private HandlerInterceptorAdapter interceptor;
    
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(interceptor)
				.addPathPatterns("/")
				.excludePathPatterns("/..");
	}
}
