package com.example.demo.DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.Model.MyClient;


@Repository
public class HibernateORM implements ORM {
	
	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;
	@PersistenceContext
	private EntityManager entityManager;

	@Override	
	@Transactional
	public MyClient store(MyClient client) {
		return entityManager.merge(client);
	}

	@Override
	@Transactional
	public void delete(String ID) {
		entityManager.remove(ID);
	}

	@Override
	@Transactional(readOnly = true)
	public MyClient findById(String ID) {
		return entityManager.find(MyClient.class, ID);
	}

	@Override
	@Transactional(readOnly = true)
	public List<MyClient> findAll() {
		return entityManager.createQuery("SELECT i FROM MyClient i", MyClient.class).getResultList();
	}

}
