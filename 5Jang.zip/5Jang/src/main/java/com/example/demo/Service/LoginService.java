package com.example.demo.Service;

import com.example.demo.Model.MyClient;

public interface LoginService {
	public void SignUp(MyClient client);
	public int login(MyClient client);
	public boolean overlapCheck(MyClient client);
	public String getClientType(MyClient client);
	public void addClient(MyClient client);
}
