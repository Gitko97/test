package com.example.demo.DAO;

import java.util.List;

import com.example.demo.Model.MyClient;

public interface ORM {
	MyClient store(MyClient client);
	void delete(String ID);
	MyClient findById(String ID);
	List<MyClient> findAll();
}
