package com.example.demo.Service;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.HibernateORM;
import com.example.demo.Model.MyClient;

@Service
@XmlRootElement(name="clientList")
@XmlAccessorType(XmlAccessType.FIELD)
public class ClientListServiceImpl implements ClientListService {
	
	@XmlElement(name="myclient")
	private  List<MyClient> clientList;
	@Autowired
	private HibernateORM hibernateORM;
	
	@Autowired
	public ClientListServiceImpl(HibernateORM hibernateORM) {
		this.hibernateORM = hibernateORM;
		clientList = hibernateORM.findAll();
	}
	@Override
	public boolean checkOverLap(String inputID) {
		try {
			for(int i =0; i < clientList.size(); i++) {
				MyClient c = clientList.get(i);
				if(c.equalID(inputID)) return true;
			}
//		for(Client client : clientList) {
//			if(client.equalID(inputID)) return true;
//		}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public void addClient(MyClient client) {
		clientList.add(client);
		hibernateORM.store(client);
	}

	@Override
	public boolean clientLogin(String inputID, String inputPassword) {
		for(MyClient client : clientList) {
			if(client.equalID(inputID) && client.equalPassword(inputPassword))
				return true;
		}
		return false;
	}

	public void print() {
		for(MyClient client : clientList) {
			System.out.println(client.toString());
		}
	}


	
	@Override
	public List<MyClient> getClientList() {
		return this.clientList;
	}

	@Override
	public MyClient findClient(String inputID) {
		for(MyClient client : clientList) {
			if(client.equalID(inputID)) return client;
		}
		return null;
	}

	@Override
	public List<MyClient> findClientName(String inputName) {
		List<MyClient> findedClient = new ArrayList<>();
		for(MyClient client : clientList) {
			if(client.equalID(inputName)) findedClient.add(client);
		}
		return findedClient;
	}

	@Override
	public void setList(List<MyClient> clients) {
		this.clientList = clients;
	}

	@Override
	public void deleteClient(String ID) {
		hibernateORM.delete(ID);
	}
	
}
