package com.example.demo.Model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Service;

@Service
@XmlRootElement(name="tempList")
@XmlAccessorType(XmlAccessType.FIELD)
public class TemperatureListImpl  implements TemperatureList {

	@XmlElement(name="temperature")
	private List<TemperatureModel> tempList = new ArrayList<>();

	public List<TemperatureModel> getTempList() {
		return tempList;
	}

	public void setTempList(List<TemperatureModel> tempList) {
		this.tempList = tempList;
	}

	@Override
	public void findTemp(int temperature) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addTemp(TemperatureModel temp) {
		this.tempList.add(temp);
	}
	
}
