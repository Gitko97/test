package com.example.demo.CoAPServer;

import org.eclipse.californium.core.CoapServer;
import org.eclipse.californium.core.coap.Request;
import org.eclipse.californium.core.coap.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.example.demo.CoAPResources.HelloWorldResource;
import com.example.demo.CoAPResources.ImageResource;
import com.example.demo.CoAPResources.LargeResource;
import com.example.demo.CoAPResources.MirrorResource;
import com.example.demo.CoAPResources.StorageResource;
import com.example.demo.CoAPResources.TemperatureResource;

@Component
public class CoAPServer extends CoapServer {
	
	@Autowired
	public CoAPServer(TemperatureResource temp) {
		this.add(temp);
		this.add(new HelloWorldResource("hello"));
		this.add(new StorageResource("storage"));
		this.add(new ImageResource("image"));
		this.add(new MirrorResource("mirror"));
		this.add(new LargeResource("large"));
		this.start();
		selfTest();
	}
	
	/*
	 *  Sends a GET request to itself
	 */
	public static void selfTest() {
		try {
			Request request = Request.newGet();
			request.setURI("localhost:5683/hello");
			request.send();
			Response response = request.waitForResponse(1000);
			System.out.println("received "+response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
