package com.example.demo.CoAPResources;

import org.eclipse.californium.core.coap.LinkFormat;
import org.eclipse.californium.core.coap.MediaTypeRegistry;

import java.io.IOException;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.eclipse.californium.core.server.resources.Resource;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.client.RestTemplate;

import com.example.demo.Model.TemperatureList;
import com.example.demo.Model.TemperatureModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class TemperatureResource extends CoapResource {

	private String content;
	
	@Autowired
	private TemperatureList temperature;
	
	private RestTemplate restTemplate = new RestTemplate();
	private ObjectMapper objectMapper = new ObjectMapper();
	
	public TemperatureResource(@Value("temp")String name) {
		super(name);
	}
	
	@Override
	public void handleGET(CoapExchange exchange) {
		if (content != null) {
			exchange.respond(content);
		} else {
			String subtree = LinkFormat.serializeTree(this);
			exchange.respond(ResponseCode.CONTENT, subtree, MediaTypeRegistry.APPLICATION_LINK_FORMAT);
		}
	}

	@Override
	public void handlePOST(CoapExchange exchange) {
		exchange.respond(ResponseCode.CONTENT);
		
		String xml = exchange.getRequestText();
		System.out.println(exchange.getRequestText());
		JSONObject jsonObject = XML.toJSONObject(xml);
		System.out.println(jsonObject.toString());
		try {
			temperature.addTemp(objectMapper.readValue(jsonObject.toString(), TemperatureModel.class));
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void handlePUT(CoapExchange exchange) {
		content = exchange.getRequestText();
		exchange.respond(ResponseCode.CHANGED);
	}

	@Override
	public void handleDELETE(CoapExchange exchange) {
		this.delete();
		exchange.respond(ResponseCode.DELETED);
	}

	/**
	 * Find the requested child. If the child does not exist yet, create it.
	 */
	@Override
	public Resource getChild(String name) {
		Resource resource = super.getChild(name);
		if (resource == null) {
			resource = new StorageResource(name);
			add(resource);
		}
		return resource;
	}
}
