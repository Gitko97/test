package com.example.demo.Model;

import java.util.List;

public interface TemperatureList{
	public void addTemp(TemperatureModel temp);
	public void findTemp(int temperature);
	public List<TemperatureModel> getTempList();
	public void setTempList(List<TemperatureModel> tempList);
}
