package com.example.demo.Config;

import javax.servlet.Filter;
import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;



public class MVCConfiguration extends AbstractAnnotationConfigDispatcherServletInitializer{

	@Override
	protected Class<?>[] getRootConfigClasses() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		return null;
//		return new Class[] {ResolverConfiguration.class};
	}

	@Override
	protected String[] getServletMappings() {
		return new String[] {"/"};
	}
	

	
	
	  @Override public void onStartup(ServletContext servletContext) throws
	  ServletException { FilterRegistration charEncodingFilterReg =
	  servletContext.addFilter("CharacterEncodingFilter",
	  CharacterEncodingFilter.class);
	  charEncodingFilterReg.setInitParameter("encoding", "UTF-8");
	  charEncodingFilterReg.setInitParameter("forceEncoding", "true");
	  charEncodingFilterReg.addMappingForUrlPatterns(null, true, "/");
	  
	  }
	  //인코딩 도움 안됨
	
}