package com.example.demo.CoAPServer;

import org.eclipse.californium.core.CoapServer;
import org.eclipse.californium.core.coap.Request;
import org.eclipse.californium.core.coap.Response;
import com.example.demo.CoAPResources.HelloWorldResource;
import com.example.demo.CoAPResources.ImageResource;
import com.example.demo.CoAPResources.LargeResource;
import com.example.demo.CoAPResources.MirrorResource;
import com.example.demo.CoAPResources.StorageResource;

public class ExampleServer {

	/*
	 * public static void main(String[] args) throws Exception { CoapServer server =
	 * new CoapServer();
	 * 
	 * server.add(new HelloWorldResource("hello")); server.add(new
	 * FibonacciResource("fibonacci")); server.add(new StorageResource("storage"));
	 * server.add(new ImageResource("image")); server.add(new
	 * MirrorResource("mirror")); server.add(new LargeResource("large"));
	 * server.start(); selfTest(); }
	 * 
	 * 
	 * Sends a GET request to itself
	 * 
	 * public static void selfTest() { try { Request request = Request.newGet();
	 * request.setURI("localhost:5683/hello"); request.send(); Response response =
	 * request.waitForResponse(1000); System.out.println("received "+response); }
	 * catch (Exception e) { e.printStackTrace(); } }
	 */
}
