
package com.example.demo.Config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@SpringBootApplication
@Configuration
@EnableWebMvc
@ComponentScan("com.example.demo")
public class SampleSpringApplication {
	public static void main(String[] args) {
		SpringApplication.run(SampleSpringApplication.class, args);
	}
}