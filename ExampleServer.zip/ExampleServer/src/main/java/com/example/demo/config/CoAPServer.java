package com.example.demo.config;

import javax.annotation.Resource;

import org.eclipse.californium.core.CoapServer;
import org.eclipse.californium.core.coap.Request;
import org.eclipse.californium.core.coap.Response;
import org.springframework.stereotype.Component;

import com.example.demo.resource.HelloWorldResource;
import com.example.demo.resource.TemperatureResource;


@Component
public class CoAPServer extends CoapServer {
	
	@Resource
	private TemperatureResource temperatureResource;
	@Resource
	private HelloWorldResource helloWorldResource;
	
	public void init() {
		this.add(helloWorldResource);
		this.add(temperatureResource);
		this.start();
		selfTest();
	}
	/*
	 *  Sends a GET request to itself
	 */
	public static void selfTest() {
		try {
			Request request = Request.newGet();
			request.setURI("localhost:5683/hello");
			request.send();
			Response response = request.waitForResponse(1000);
			System.out.println("received "+response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
