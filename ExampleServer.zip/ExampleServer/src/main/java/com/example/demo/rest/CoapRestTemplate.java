package com.example.demo.rest;

import org.json.JSONObject;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class CoapRestTemplate {
	
	private final String httpServerUrl="http://localhost:8080/userListInfo";
	private RestTemplate restTemplate = new RestTemplate();
	
	public void handlePOST(JSONObject jsonObject) {
		System.out.println("POST");
//		restTemplate.postForEntity(httpServerUrl, jsonObject, String.class);
	}
}
