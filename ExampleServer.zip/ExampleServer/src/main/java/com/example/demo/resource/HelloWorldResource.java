package com.example.demo.resource;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("helloWorldResource")
public class HelloWorldResource extends CoapResource {

	@Autowired
	private TemperatureResource temperatureResource;
	
	public HelloWorldResource() {
		super("hello");
	}
	
	@Override
	public void handleGET(CoapExchange exchange) {
		System.out.println(exchange.getSourcePort());
		exchange.respond("hello world~");
	}

	
	@Override
	public void handlePOST(CoapExchange exchange) {
		//데이터 확인 후 Resource 추가
		String name = exchange.getRequestText();
		if(name == null) exchange.respond(ResponseCode.BAD_REQUEST);
		else {
			temperatureResource.getChild(name);
			exchange.respond(ResponseCode.CONTENT);
		}
	}
}
