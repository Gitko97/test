package com.example.demo.resource;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.eclipse.californium.core.server.resources.Resource;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.example.demo.rest.CoapRestTemplate;

@Component
public class TemperatureResource extends CoapResource {

	private CoapRestTemplate coapRestTemplate;

	@Autowired
	public TemperatureResource(CoapRestTemplate coapRestTemplate) {
		super("temperature");
		this.coapRestTemplate = coapRestTemplate;
	}
	
	public TemperatureResource(String name) {
		super(name);
	}

	@Override
	public void handleGET(CoapExchange exchange) {
		/*
		 * if (content != null) { exchange.respond(content); } else { String subtree =
		 * LinkFormat.serializeTree(this); exchange.respond(ResponseCode.CONTENT,
		 * subtree, MediaTypeRegistry.APPLICATION_LINK_FORMAT); }
		 */
	}

	@Override
	public void handlePOST(CoapExchange exchange) {
		
		System.out.println(" : "+ exchange);
		System.out.println("Exchange : "+ exchange.getSourceAddress().toString());
		System.out.println("SourcePort : "+ exchange.getSourcePort());
		System.out.println(" : "+ exchange.getRequestCode());
		System.out.println(" : "+ exchange.getRequestOptions().getUriPathString());
		System.out.println(" : "+ exchange.getRequestPayload());
		String xml = exchange.getRequestText();
		try {
			if(xml == null) throw new JSONException(xml);
			JSONObject jsonObj = new JSONObject(xml);
			coapRestTemplate.handlePOST(jsonObj);
			exchange.respond(ResponseCode.CONTENT);
		}catch(JSONException jsonException) {
			jsonException.printStackTrace();
			exchange.respond(ResponseCode.BAD_REQUEST);
		}
	}

	@Override
	public void handlePUT(CoapExchange exchange) {
//		content = exchange.getRequestText();
		exchange.respond(ResponseCode.CHANGED);
	}

	@Override
	public void handleDELETE(CoapExchange exchange) {
		this.delete();
		exchange.respond(ResponseCode.DELETED);
	}

	@Override
	public Resource getChild(String name) {
		Resource resource = super.getChild(name);
		if (resource == null) {
			resource = new TemperatureResource(name);
			add(resource);
		}
		return resource;
	}

	/**
	 * Find the requested child. If the child does not exist yet, create it.
	 */
	
}
